import 'package:flutter/material.dart';
import '/app_localizations.dart';

class LanguageSwitcher extends StatelessWidget {
  final Function(Locale) onLanguageChanged;

  const LanguageSwitcher({super.key, required this.onLanguageChanged});

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return FloatingActionButton(
      onPressed: () {
        final currentLocale = Localizations.localeOf(context);
        final newLocale = currentLocale.languageCode == 'vi'
            ? const Locale('en', 'US')
            : const Locale('vi', 'VN');

        onLanguageChanged(newLocale);
      },
      tooltip: localizations.translate('change_language'),
      child: const Icon(Icons.language),
    );
  }
}
