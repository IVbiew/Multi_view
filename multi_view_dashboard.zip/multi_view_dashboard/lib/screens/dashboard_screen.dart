import 'package:flutter/material.dart';
import '/widgets/custom_app_bar.dart';
import '/widgets/language_switcher.dart';
import 'language_screen.dart';
import 'about_screen.dart';
import '/app_localizations.dart';

class DashboardScreen extends StatefulWidget {
  final Function(Locale) onLanguageChanged;

  const DashboardScreen({super.key, required this.onLanguageChanged});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    List<Widget> screens = [
      const LanguageScreen(),
      const AboutScreen(),
    ];

    return Scaffold(
      appBar: CustomAppBar(
        title: localizations.translate('app_title'),
      ),
      body: screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: const Icon(Icons.dashboard),
            label: localizations.translate('dashboard'),
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.info),
            label: localizations.translate('about'),
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
      floatingActionButton: LanguageSwitcher(
        onLanguageChanged: widget.onLanguageChanged,
      ),
    );
  }
}
