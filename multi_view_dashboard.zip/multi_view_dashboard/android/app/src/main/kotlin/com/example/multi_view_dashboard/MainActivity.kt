package com.example.multi_view_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
